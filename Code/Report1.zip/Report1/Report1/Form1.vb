﻿Option Explicit Off
Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        student_id.Text = "634272106"
        Student_Name.Text = "Nitpichtha"
        Student_Email.Text = "nitpichtha.kae@mail.pbru.ac.th"
        Dim birthdate As Date = #3/8/2001#
        Dim age As Integer

        age = Year(Today()) - Year(birthdate)
        student_age.Text = age.ToString & "วันเกิด" & birthdate.ToString("dddd")
        student_enroll.Text = (16000 * 8).ToString("฿#,###")
    End Sub
End Class
